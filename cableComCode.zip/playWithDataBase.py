
from createDataBase_upc import *
from createRandomInfo import *
from analyzeDB import *

def playWithDataBase():

	#CREATE THE DATABSAE 
	createTables()

